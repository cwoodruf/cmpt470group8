<?php
/**
 * default controller - customize it
 *
 * you can use the $this->actions array to select which action you want to do
 * use $this->doable(array( ...map of action to callback funcs...));
 * and $this->doaction($this->actions[1]);
 * to handle sub actions such as home/someaction
 *
 * you can display templates with the default smarty view code 
 * View::assign - to assign template variables
 * View::display - display the template
 * View::wrap - display template in a wrapper 
 */
class Home extends Controller {
	/**
	 * required function for controllers
	 */

	protected $u;
	public function execute() {
		$this->u = new User;
		$this->schema = $this->u->schema;
		$this->schema['password']['template'] = 'tools/newpassword.tpl';
	
		# an edit form for each record: works with tools/dump.tpl used by tools/dumpall.tpl below
		View::assign('form','tools/editgen.tpl');
		View::assign('formkey','email');

		$this->doable(array(
			'save' => 'saveuser',
			'edit' => 'edituser',
			'delete' => 'confirmdel',
			'really_delete' => 'deluser',
			'default' => 'scanurl',
		));
		$this->doaction($this->actions[1]);

		# get every record and add it to an array $list 
		View::assign('list',$this->u->getall());
		# add an html list of all users
		View::assign('dumpall',View::fetch('tools/dumpall.tpl'));

		View::wrap('home.tpl');
	}
	protected function saveuser() {
		# add a new record to the users table
		if ($this->u->getone($_REQUEST['email'])) {
			$return = $this->u->upd($_REQUEST['email'],$_REQUEST);
		} else {
			$return = $this->u->ins($_REQUEST);
		}
		if (!$return) View::assign('error',$this->u->err());
	}
	protected function edituser() {
		$user = $this->u->getone($_REQUEST['formkey']);
		View::assign('name',$user['email']);
		$this->input = $user;
	}
	protected function confirmdel() {
		$email = $_REQUEST['formkey'];
		# this is input to the confirm.tpl template
		$this->input = array(
			'confirm' => "Really delete $email?",
			'action' => "home/really_delete",
			'what' => $email,
			'submit' => 'delete',
		);
		View::assign('topform',View::fetch('tools/confirm.tpl'));
	}
	protected function deluser() {
		$email = $_REQUEST['what'];
		$this->u->del($email);
		View::assign('confirm',"Deleted $email");
		View::assign('topform',View::fetch('tools/confirm.tpl'));
	}
	protected function scanurl() {
		View::assign('name',htmlentities($this->actions[1]));
		View::assign('question',htmlentities($this->actions[2]));
	}
}

